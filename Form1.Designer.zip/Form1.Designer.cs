﻿namespace tarea2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.bus1 = new System.Windows.Forms.CheckBox();
            this.bus2 = new System.Windows.Forms.CheckBox();
            this.bus3 = new System.Windows.Forms.CheckBox();
            this.formulario2 = new System.Windows.Forms.Button();
            this.resultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(80, 129);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 43);
            this.button1.TabIndex = 0;
            this.button1.Text = "comprar ticket";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "AUTOBUSES DISPONIBLES ";
            // 
            // bus1
            // 
            this.bus1.AutoSize = true;
            this.bus1.Location = new System.Drawing.Point(89, 49);
            this.bus1.Name = "bus1";
            this.bus1.Size = new System.Drawing.Size(140, 17);
            this.bus1.TabIndex = 2;
            this.bus1.Text = "a san salvador 8:30 $15";
            this.bus1.UseVisualStyleBackColor = true;
            // 
            // bus2
            // 
            this.bus2.AutoSize = true;
            this.bus2.Location = new System.Drawing.Point(89, 72);
            this.bus2.Name = "bus2";
            this.bus2.Size = new System.Drawing.Size(145, 17);
            this.bus2.TabIndex = 3;
            this.bus2.Text = "a chalatenango 9:30 $20";
            this.bus2.UseVisualStyleBackColor = true;
            // 
            // bus3
            // 
            this.bus3.AutoSize = true;
            this.bus3.Location = new System.Drawing.Point(89, 95);
            this.bus3.Name = "bus3";
            this.bus3.Size = new System.Drawing.Size(136, 17);
            this.bus3.TabIndex = 4;
            this.bus3.Text = "a la frontera 11:00 $ 50";
            this.bus3.UseVisualStyleBackColor = true;
            // 
            // formulario2
            // 
            this.formulario2.Location = new System.Drawing.Point(80, 235);
            this.formulario2.Name = "formulario2";
            this.formulario2.Size = new System.Drawing.Size(75, 23);
            this.formulario2.TabIndex = 5;
            this.formulario2.Text = "siguiente";
            this.formulario2.UseVisualStyleBackColor = true;
            this.formulario2.Click += new System.EventHandler(this.formulario2_Click);
            // 
            // resultado
            // 
            this.resultado.Location = new System.Drawing.Point(80, 190);
            this.resultado.Name = "resultado";
            this.resultado.Size = new System.Drawing.Size(100, 20);
            this.resultado.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 270);
            this.Controls.Add(this.resultado);
            this.Controls.Add(this.formulario2);
            this.Controls.Add(this.bus3);
            this.Controls.Add(this.bus2);
            this.Controls.Add(this.bus1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button formulario2;
        public System.Windows.Forms.TextBox resultado;
        public System.Windows.Forms.CheckBox bus1;
        public System.Windows.Forms.CheckBox bus2;
        public System.Windows.Forms.CheckBox bus3;
    }
}

