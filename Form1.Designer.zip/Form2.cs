﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tarea2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int total = 0;
            int tarjeta1 = 60;
            int efectivo1 = 20;

            if (tarjeta.Checked == true)
            {
                total = total + tarjeta1;
                totalPagar.Text = total.ToString();
            }
            if (efectivo.Checked == true)
            {
                total = total + efectivo1;
                totalPagar.Text = total.ToString();
            }

        }

        private void busito1_Click(object sender, EventArgs e)
        {
            if (busito1.Text == "bus1")
            {
                MessageBox.Show("total a pagar por ir a san salvador es de 15");


            }
        }

        private void busito2_Click(object sender, EventArgs e)
        {
            if (busito2.Text == "bus2")
            {
                MessageBox.Show("total a pagar por ir a chalatenango es de 20");


            }
        }

        private void busito3_Click(object sender, EventArgs e)
        {
            if (busito3.Text == "bus3")
            {
                MessageBox.Show("total a pagar po ir a la frontera es de 50");


            }
        }
    }
}  
    
    

 
