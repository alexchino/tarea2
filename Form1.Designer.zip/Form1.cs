﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tarea2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string opcion = Name;
            if (bus1.Checked == true)
                opcion = bus1.Name;
            if (bus2.Checked == true)
                opcion = bus2.Name;
            if (bus3.Checked == true)
                opcion = bus3.Name;
            
            resultado.Text = opcion;
        }

        private void formulario2_Click(object sender, EventArgs e)
        {
            Form formulario2 = new Form2();
            formulario2.Show();
        }
    }
}
