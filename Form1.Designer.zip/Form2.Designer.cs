﻿namespace tarea2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tarjeta = new System.Windows.Forms.CheckBox();
            this.efectivo = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.totalPagar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.busito3 = new System.Windows.Forms.Button();
            this.busito2 = new System.Windows.Forms.Button();
            this.busito1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(79, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "METODO DE PAGO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tarjeta
            // 
            this.tarjeta.AutoSize = true;
            this.tarjeta.Location = new System.Drawing.Point(82, 63);
            this.tarjeta.Name = "tarjeta";
            this.tarjeta.Size = new System.Drawing.Size(105, 17);
            this.tarjeta.TabIndex = 1;
            this.tarjeta.Text = "tarjeta de credito";
            this.tarjeta.UseVisualStyleBackColor = true;
            // 
            // efectivo
            // 
            this.efectivo.AutoSize = true;
            this.efectivo.Location = new System.Drawing.Point(82, 99);
            this.efectivo.Name = "efectivo";
            this.efectivo.Size = new System.Drawing.Size(64, 17);
            this.efectivo.TabIndex = 2;
            this.efectivo.Text = "efectivo";
            this.efectivo.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(82, 122);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 42);
            this.button1.TabIndex = 3;
            this.button1.Text = "fondos disponibles ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // totalPagar
            // 
            this.totalPagar.Location = new System.Drawing.Point(82, 170);
            this.totalPagar.Name = "totalPagar";
            this.totalPagar.Size = new System.Drawing.Size(100, 20);
            this.totalPagar.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(88, 358);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "total a pagar ";
            // 
            // busito3
            // 
            this.busito3.Location = new System.Drawing.Point(82, 307);
            this.busito3.Name = "busito3";
            this.busito3.Size = new System.Drawing.Size(75, 24);
            this.busito3.TabIndex = 8;
            this.busito3.Text = "bus3";
            this.busito3.UseVisualStyleBackColor = true;
            this.busito3.Click += new System.EventHandler(this.busito3_Click);
            // 
            // busito2
            // 
            this.busito2.Location = new System.Drawing.Point(82, 273);
            this.busito2.Name = "busito2";
            this.busito2.Size = new System.Drawing.Size(75, 28);
            this.busito2.TabIndex = 9;
            this.busito2.Text = "bus2";
            this.busito2.UseVisualStyleBackColor = true;
            this.busito2.Click += new System.EventHandler(this.busito2_Click);
            // 
            // busito1
            // 
            this.busito1.Location = new System.Drawing.Point(82, 239);
            this.busito1.Name = "busito1";
            this.busito1.Size = new System.Drawing.Size(75, 28);
            this.busito1.TabIndex = 10;
            this.busito1.Text = "bus1";
            this.busito1.UseVisualStyleBackColor = true;
            this.busito1.Click += new System.EventHandler(this.busito1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(164, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "presiona el bus en el que saldras ";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(261, 445);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.busito1);
            this.Controls.Add(this.busito2);
            this.Controls.Add(this.busito3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.totalPagar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.efectivo);
            this.Controls.Add(this.tarjeta);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox tarjeta;
        private System.Windows.Forms.CheckBox efectivo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox totalPagar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button busito3;
        private System.Windows.Forms.Button busito2;
        private System.Windows.Forms.Button busito1;
        private System.Windows.Forms.Label label3;
    }
}